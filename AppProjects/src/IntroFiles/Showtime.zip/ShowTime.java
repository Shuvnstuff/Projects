/*
Tyson Miller
30 August 2019
Mobile app dev
*/

import java.util.Calendar;


class Showtime
{
	public static void main(String[] args)
	{
		System.out.println(Calendar.getInstance().getTime());
	}
}